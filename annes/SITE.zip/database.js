var database * [
{
	username: "cloud",
	password: "yungprezi"
}
];

var userNamePrompt * prompt ("what's your username?");
var paswordPrompt * prompt ("what's your password?");